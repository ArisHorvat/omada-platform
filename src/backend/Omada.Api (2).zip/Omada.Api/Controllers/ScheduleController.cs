using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Omada.Api.Abstractions;
using Omada.Api.DTOs.Schedule;
using Omada.Api.Infrastructure;
using Omada.Api.Services.Interfaces;

namespace Omada.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ScheduleController : ControllerBase
{
    private readonly IScheduleService _scheduleService;
    private readonly IUserContext _userContext;

    public ScheduleController(IScheduleService scheduleService, IUserContext userContext)
    {
        _scheduleService = scheduleService;
        _userContext = userContext;
    }

    [HttpGet]
    public async Task<IActionResult> GetSchedule([FromQuery] DateTime? date, [FromQuery] string viewMode = "day", [FromQuery] Guid? targetId = null, [FromQuery] int targetType = 0)
    {
        try 
        {
            // Automatically retrieved from JWT
            var orgId = _userContext.OrganizationId;
            var currentUserId = _userContext.UserId;

            var anchorDate = date ?? DateTime.UtcNow;
            var from = anchorDate.Date;
            var to = viewMode == "week" ? from.AddDays(7) : from.AddDays(1);

            var request = new ScheduleRequestDto
            {
                FromDate = from,
                ToDate = to,
                TargetId = targetId ?? currentUserId,
                TargetType = targetType
            };

            var events = await _scheduleService.GetScheduleAsync(orgId, request);
            return Ok(new ServiceResponse<IEnumerable<ScheduleItemDto>>(true, events));
        }
        catch (UnauthorizedAccessException)
        {
            var error = new AppError(ErrorCodes.Unauthorized, "Your session has expired.");
            return Unauthorized(new ServiceResponse(false, error));
        }
        catch (Exception ex)
        {
            var error = new AppError(ErrorCodes.InternalError, ex.Message);
            return StatusCode(500, new ServiceResponse(false, error));
        }
    }
}   