using Microsoft.AspNetCore.Mvc;
using Omada.Api.Services.Interfaces;
using Omada.Api.Abstractions;

namespace Omada.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ToolsController : ControllerBase
{
    private readonly IColorExtractionService _colorService;
    private readonly IImportService _importService;

    public ToolsController(IColorExtractionService colorService, IImportService importService)
    {
        _colorService = colorService;
        _importService = importService;
    }

    [HttpPost("extract-colors")]
    public async Task<IActionResult> ExtractColors(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.InvalidInput, "No file uploaded")));

        using var stream = file.OpenReadStream();
        var colors = await _colorService.ExtractColorsAsync(stream);
        
        return Ok(new ServiceResponse<IEnumerable<string>>(true, colors));
    }

    [HttpPost("parse-users")]
    public async Task<IActionResult> ParseUsers(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.InvalidInput, "No file uploaded")));

        using var stream = file.OpenReadStream();
        var users = await _importService.ParseUsersAsync(stream, file.FileName);
        
        return Ok(new ServiceResponse<object>(true, users));
    }
}