using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Omada.Api.Repositories.Interfaces;
using Omada.Api.DTOs.Users;
using Omada.Api.Abstractions;

namespace Omada.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly IUserRepository _userRepository;
    private readonly ILogger<UsersController> _logger;

    public UsersController(IUserRepository userRepository, ILogger<UsersController> logger)
    {
        _userRepository = userRepository;
        _logger = logger;
    }

    private Guid GetUserId()
    {
        // Extracts the User ID from the JWT token claims
        var id = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(id)) throw new UnauthorizedAccessException();
        return Guid.Parse(id);
    }

   [HttpGet("me")]
    public async Task<IActionResult> GetMe()
    {
        try 
        {
            var userId = GetUserId();
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null) 
                return NotFound(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.NotFound, "User not found")));
            
            return Ok(new ServiceResponse<object>(true, user));
        }
        catch (Exception ex)
        {
            return Unauthorized(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.Unauthorized, ex.Message)));
        }
    }

    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest request)
    {
        try
        {
            var userId = GetUserId();
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null) return NotFound();

            if (!BCrypt.Net.BCrypt.Verify(request.OldPassword, user.PasswordHash))
            {
                return BadRequest("Incorrect current password.");
            }

            user.ChangePassword(BCrypt.Net.BCrypt.HashPassword(request.NewPassword));
            await _userRepository.UpdateAsync(user);

            return Ok(new { message = "Password updated successfully." });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
    }

    [HttpPut("security")]
    public async Task<IActionResult> UpdateSecurity([FromBody] UpdateSecurityRequest request)
    {
        try
        {
            var userId = GetUserId();
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null) return NotFound();

            user.ToggleTwoFactor(request.IsTwoFactorEnabled);
            await _userRepository.UpdateAsync(user);

            return Ok(new { message = "Security settings updated." });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
    }

    [HttpPut("profile")]
    public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request)
    {
        var userId = GetUserId();
        var user = await _userRepository.GetByIdAsync(userId);
        if (user == null) return NotFound(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.NotFound, "User not found")));

        user.UpdateProfile(request.PhoneNumber, request.Address, request.ProfilePictureUrl);
        await _userRepository.UpdateAsync(user);

        return Ok(new ServiceResponse<object>(true, new { message = "Profile updated successfully" }));
    }
}
