using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Omada.Api.Services.Interfaces;
using Omada.Api.WebSocketHandlers;
using Omada.Api.Services; 
using Omada.Api.DTOs.Organizations;
using Omada.Api.Abstractions;

namespace Omada.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrganizationsController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly IWebSocketHandler _webSocketHandler;
    private readonly ILogger<OrganizationsController> _logger;

    public OrganizationsController(IOrganizationService organizationService, IWebSocketHandler webSocketHandler, ILogger<OrganizationsController> logger)
    {
        _organizationService = organizationService;
        _webSocketHandler = webSocketHandler;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> Create(RegisterOrganizationRequest request)
    {
        var result = await _organizationService.CreateOrganizationAsync(request);

        if (result.IsFailure)
        {
            return BadRequest(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.OperationFailed, result.Error)));
        }

        return Ok(new ServiceResponse<object>(true, new { id = result }));
    }

    [HttpPut("{id:guid}")]
    // [Authorize(Roles = "SuperAdmin")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, UpdateOrganizationRequest request)
    {
        _logger.LogInformation("Received request to update organization: {Id}", id);
        var result = await _organizationService.UpdateOrganizationAsync(id, request);
        if (result.IsFailure)
        {
            _logger.LogWarning("Failed to update organization {Id}: {Error}", id, result.Error);
            return result.Error!.Contains("not found") ? NotFound() : BadRequest(new { Error = result.Error });
        }
        return Ok(result.Value);
    }

    [HttpDelete("{id:guid}")]
    // [Authorize(Roles = "SuperAdmin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id)
    {
        _logger.LogInformation("Received request to delete organization: {Id}", id);
        var result = await _organizationService.DeleteOrganizationAsync(id);
        if (result.IsFailure)
        {
            _logger.LogWarning("Failed to delete organization {Id}: {Error}", id, result.Error);
            return NotFound();
        }

        return NoContent();
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var organization = await _organizationService.GetByIdAsync(id);
        if (organization == null)
        {
            return NotFound(new ServiceResponse<object>(false, null, new AppError(ErrorCodes.NotFound, "Organization not found")));
        }

        return Ok(new ServiceResponse<OrganizationDetailsDto>(true, organization));
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var organizations = await _organizationService.GetAllAsync();
        return Ok(new ServiceResponse<IEnumerable<OrganizationDetailsDto>>(true, organizations));
    }

    [HttpGet("/ws/organizations")]
    public async Task GetWebSocket([FromQuery] Guid orgId)
    {
        if (HttpContext.WebSockets.IsWebSocketRequest)
        {
            _logger.LogInformation("Accepting WebSocket connection for Org: {OrgId}", orgId);
            using var webSocket = await HttpContext.WebSockets.AcceptWebSocketAsync();
            await _webSocketHandler.HandleAsync(webSocket, orgId);
        }
        else
        {
            _logger.LogWarning("Invalid WebSocket request");
            HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
        }
    }
}
