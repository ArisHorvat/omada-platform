using Omada.Api.Services.Interfaces;
using Omada.Api.DTOs.Schedule;
using Omada.Api.Repositories.Interfaces;

namespace Omada.Api.Services;

public class ScheduleService : IScheduleService
{
    private readonly IScheduleRepository _repo;

    public ScheduleService(IScheduleRepository repo)
    {
        _repo = repo;
    }

    public async Task<IEnumerable<ScheduleItemDto>> GetScheduleAsync(Guid orgId, ScheduleRequestDto request)
    {
        // Future Logic: This is where we would expand Recurring Patterns (RRULE).
        // For now, we pass through to the database.
        
        return await _repo.GetEventsAsync(
            orgId, 
            request.FromDate, 
            request.ToDate, 
            request.TargetId.Value, 
            request.TargetType
        );
    }
}