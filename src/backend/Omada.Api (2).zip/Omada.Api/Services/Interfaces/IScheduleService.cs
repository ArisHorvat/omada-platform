using Omada.Api.DTOs.Schedule;

namespace Omada.Api.Services.Interfaces;

public interface IScheduleService
{
    Task<IEnumerable<ScheduleItemDto>> GetScheduleAsync(Guid orgId, ScheduleRequestDto request);
}