using System;

namespace Omada.Api.DTOs.Schedule
{
    public class ScheduleItemDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Subtitle { get; set; } // e.g. "Room 304" or "Prof. Smith"
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int Type { get; set; } // 0=Class, 1=Meeting, etc.
        public string Color { get; set; } // Hex Code override
        public string RecurrenceRule { get; set; }
    }
}