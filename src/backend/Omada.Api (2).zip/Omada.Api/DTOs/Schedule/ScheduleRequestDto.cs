using System;

namespace Omada.Api.DTOs.Schedule
{
    public class ScheduleRequestDto
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        
        // Polymorphic Filters
        // If TargetId is null, the controller will default to the Current User
        public Guid? TargetId { get; set; } 
        
        // 0 = User, 1 = Group, 2 = Room
        public int TargetType { get; set; } = 0; 
    }
}